class Publisher:

    def __init__(self, id_, name):
        self.id_ = id_
        self.name = name

    def get_id(self):
        return self.id_

    def get_name(self):
        return self.name
